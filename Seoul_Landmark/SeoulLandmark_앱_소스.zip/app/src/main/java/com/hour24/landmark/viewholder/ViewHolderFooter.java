package com.hour24.landmark.viewholder;

import android.view.View;
import com.hour24.landmark.model.VisionModel;

public class ViewHolderFooter {

    private View view;

    public ViewHolderFooter(View view) {
        this.view = view;
        initLayout();
    }

    private void initLayout() {
    }

    public void bind(int position, VisionModel record) {

    }
}
