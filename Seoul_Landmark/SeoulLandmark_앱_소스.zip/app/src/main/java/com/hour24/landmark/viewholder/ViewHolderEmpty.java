package com.hour24.landmark.viewholder;

public class ViewHolderEmpty {

    public ViewHolderEmpty() {
    }

    public void bind() {

    }
}
