package com.hour24.landmark.constant;

public class PermissionConst {

    public static final int PERMISSION_CAMERA_UPLOAD = 50;
    public static final int PERMISSION_DOCUMENT_GALLERY_UPLOAD = 51;
}
